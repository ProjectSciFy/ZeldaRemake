﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSE3902_Game_Sprint0
{
    public interface ICommand
    {
        void Execute();
    }
}
